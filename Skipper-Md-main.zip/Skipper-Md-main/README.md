<h1 align="center" style="color:#FF5733;">SKIPPER-MD</h1>
<div align="center">
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Ribeye&size=50&pause=1000&color=0000FF&center=true&width=910&height=100&lines=I'M+SKIPPER-MD;Multi+Device+Whatsapp+BotbyTonny;" alt="Typing SVG" /></a>

<p align="center">
  <img src="https://telegra.ph/file/e78fcfd78dd8f2f3f6d8e.jpg" width="700" height="300"/>
</p>

### Setup
<div align="center">
    <a href="https://github.com/Brashokish/Skipper-Md/fork">
        <img title="Skipper-Md" src="https://img.shields.io/badge/FORK%20Skipper%20Md-3498DB?style=for-the-badge&logo=stackshare" />
    </a>
</div>

## Pair with WhatsApp
  <div align="center">
    <a href="https://skipper-md-session.onrender.com/">
        <img title="PAIR CODE" src="https://img.shields.io/badge/GET%20SESSION-FF5733?style=for-the-badge&logo=msi&logoColor=white" width="220" height="38.45" />
    </a>
</div>

  
<h2 style="color: #8E44AD; font-family: 'Courier New';">DEPLOY TO HEROKU</h2>
<p align="center">
    <a href="https://skipper-deploy-theta.vercel.app/">
        <img src="https://img.shields.io/badge/Heroku%20Deploy-9B59B6?style=for-the-badge&logo=heroku" width="220" height="38.45" />
    </a>

  
**2. If You Have an account on Render**
- <a href="https://render.com"><img title="Deploy Now" src="https://img.shields.io/badge/DEPLOY NOW-h?color=red&style=for-the-badge&logo=msi" width="220" height="38.45"/></a></p>

   
## Contributions

Contributions to Skipper-Md are welcome! If you have ideas for new features, improvements, or bug fixes, feel free to open an issue or submit a pull request.

## License

The SKIPPER-MD is released under the [MIT License](https://opensource.org/licenses/MIT).

Enjoy the diverse features of the Skipper-Md to enhance your conversations and make your WhatsApp experience more interesting!

## Dev owner:
- [**TONNY408**](https://instagram.com/homabayian)
- [**WhatsApp**](https://wa.me/254798780465)

## ACKNOWLEDGEMENT TO:

- [**MGTOPHAZ ZENON-AI**](https://wa.me/254705243111)
- [**KISH𓅃 Kish-MD**](https://wa.me/254745936840)
